import io

from PIL import Image
from matplotlib import pyplot as plt
import numpy as np

import felics as felics
from felics import Felics
import detector_sim as sim
from context import Context

DEFAULT_SHAPE = (64, 384)


def bench_bkg_level():
    print("Background level benchmark ---------------------------------")
    raw_size = DEFAULT_SHAPE[0] * DEFAULT_SHAPE[1] * 2.5
    im = make_signal1(DEFAULT_SHAPE, 50000)
    im += make_noise(DEFAULT_SHAPE, 5000)
    im = add_bad_pixels(im)
    im = add_vignetting(im)
    im = np.clip(im, 0, 0xfffff)
    im_base = im.astype(np.uint32)
    for bkg in range(50000, 1000000, 50000):
        im = im_base + bkg
        ctx = Context(0, 20, 13)
        buf = felics.encode(im, 20, ctx)
        ctx = Context(0, 20, 13)
        im2 = felics.decode(buf, 20, ctx)

        ok = (im == im2).any()
        print("Background = %7d: %6d -> %6d    %s" %
              (bkg, raw_size, len(buf), ok))
    print("------------------------------------------------------------")
    print()


def bench_amplitude():
    print("Amplitude benchmark ----------------------------------------")
    raw_size = DEFAULT_SHAPE[0] * DEFAULT_SHAPE[1] * 2.5
    for i in range(14, 21):
        amplitude = (1 << i) - 6000
        im = make_signal1(DEFAULT_SHAPE, amplitude)
        im += make_noise(DEFAULT_SHAPE, 5000)
        im = add_bad_pixels(im)
        im = add_vignetting(im)
        im = np.clip(im, 0, 0xfffff)
        im = im.astype(np.uint32)

        ctx = Context(0, 20, 13)
        buf = felics.encode(im, 20, ctx)
        ctx = Context(0, 20, 13)
        im2 = felics.decode(buf, 20, ctx)

        ok = (im == im2).any()
        print("Amplitude = %7d: %6d -> %6d    %s" %
              (amplitude, raw_size, len(buf), ok))
    print("------------------------------------------------------------")
    print()


def bench_bits_per_pixel():
    print("Bits per pixel benchmark -----------------------------------")
    raw_size = DEFAULT_SHAPE[0] * DEFAULT_SHAPE[1] * 2.5
    im = make_signal1(DEFAULT_SHAPE, 1000000)
    im += make_noise(DEFAULT_SHAPE, 5000)
    im = add_bad_pixels(im)
    im = add_vignetting(im)
    im = np.clip(im, 0, 0xfffff)
    im_base = im.astype(np.uint32)
    for i in range(12, 21, 2):
        im = im_base >> (20 - i)

        ctx = Context(0, 20, 13)
        buf = felics.encode(im, 20, ctx)
        ctx = Context(0, 20, 13)
        im2 = felics.decode(buf, 20, ctx)

        ok = (im == im2).any()
        print("Bits = %2d: %6d -> %6d    %s" %
              (i, raw_size, len(buf), ok))

    print("------------------------------------------------------------")
    print()


def bench_context():
    print("Context (subexponential k) benchmark -----------------------------------")
    raw_size = DEFAULT_SHAPE[0] * DEFAULT_SHAPE[1] * 2.5
    im = make_signal1(DEFAULT_SHAPE, 1000000)
    im += make_noise(DEFAULT_SHAPE, 5000)
    im = add_bad_pixels(im)
    im = add_vignetting(im)
    im = np.clip(im, 0, 0xfffff)
    im = im.astype(np.uint32)
    for m in range(4):
        for k in range(10, 15):
            e = 20 - m

            ctx = Context(m, e, k)
            buf = felics.encode(im, 20, ctx)
            ctx = Context(m, e, k)
            im2 = felics.decode(buf, 20, ctx)

            ok = (im == im2).any()
            print("Context (m=%2d e=%2d k=%d) : %6d -> %6d    %s" %
                  (m, e, k, raw_size, len(buf), ok))

    print("------------------------------------------------------------")
    print()


def bench_other_format():
    print("Compare with other format  --------------------------------")
    raw_size = DEFAULT_SHAPE[0] * DEFAULT_SHAPE[1] * 2
    im = make_signal1(DEFAULT_SHAPE, 60000)
    im += make_noise(DEFAULT_SHAPE, 5000)
    im = add_bad_pixels(im)
    im = add_vignetting(im)
    im = np.clip(im, 0, 0xffff)
    im = im.astype(np.uint16)
    im_pil = Image.fromarray(im)

    im_buf = io.BytesIO()
    im_pil.save(im_buf, "png")
    print("png: %d -> %d" % (raw_size, len(im_buf.getbuffer())))
    im_buf = io.BytesIO()
    im_pil.save(im_buf, "jpeg2000")
    print("jpeg2000: %d -> %d" % (raw_size, len(im_buf.getbuffer())))
    im_buf = io.BytesIO()
    im_pil.save(im_buf, "tiff", compression="lzma")
    print("tiff lzma: %d -> %d" % (raw_size, len(im_buf.getbuffer())))

    ctx = Context(0, 16, 12)
    buf = felics.encode(im, 16, ctx)
    print("felics: %d -> %d" % (raw_size, len(buf)))

    # ctx.plot_curve()
    plt.imshow(im, cmap="gray", interpolation='nearest')
    plt.show()

def bench_context2():
    print("Context (subexponential k) benchmark -----------------------------------")
    raw_size = DEFAULT_SHAPE[0] * DEFAULT_SHAPE[1] * 2.5
    im = make_signal1(DEFAULT_SHAPE, 1000000)
    im += make_noise(DEFAULT_SHAPE, 10000)
    im = add_bad_pixels(im)
    im = add_vignetting(im)
    im = np.clip(im, 0, 0xfffff)
    im = im.astype(np.uint32)

    ctx = Context(0, 20, 16)
    buf = felics.encode(im, 20, ctx)
    print("felics: %d -> %d" % (raw_size, len(buf)))

    ctx.plot_curve()

def simple_check():
    amplitude = 8000000
    noise = 4096
    bits = amplitude.bit_length()
    raw_size = DEFAULT_SHAPE[0] * DEFAULT_SHAPE[1] * bits / 8
    N = 5
    results = {}
    for j in range(N):
        print(j)
        im = sim.make_signal1(DEFAULT_SHAPE, amplitude)
        im += sim.make_noise(DEFAULT_SHAPE, noise)
        # im = add_bad_pixels(im)
        im = sim.add_vignetting(im)
        im = np.clip(im, 0, 0xffffff)
        im = im / 16
        im = im.astype(np.int32)
        for i in range(8,20):
            delta_min = 2**i - 1
            buf = Felics.encode(im, delta_min=delta_min)
            im2 = Felics.decode(buf)
            assert np.array_equal(im, im2)
            bits_per_pixel = len(buf)/im.size*8
            results[i] = results.setdefault(i, 0) + bits_per_pixel

    xy = list(results.items())
    xy.sort()
    xs = [x for x, _ in xy]
    ys = [y / N for _, y in xy]

    plt.plot(xs, ys)

    #print(delta_min, im.size, len(buf), len(buf)/im.size*8)
    #plt.imshow(im2, cmap="gray", interpolation='nearest')
    plt.show()

def check_delta_compression():
    common_noise = 10000
    c_noise = sim.make_noise(DEFAULT_SHAPE, common_noise)
    c_delta_min = 8191

    amplitude1 = 1000000
    amplitude2 = 1001000
    noise = 1000
    delta_min = 1023

    im1 = sim.make_signal1(DEFAULT_SHAPE, amplitude1)
    im1 += c_noise + sim.make_noise(DEFAULT_SHAPE, noise)
    im1 = sim.add_vignetting(im1)
    im1 = np.clip(im1, 0, 0xffffff)
    im1 = im1.astype(np.int32)
    im_pil = Image.fromarray(im1)
    im_pil.save("image.tiff")
    imp_pil2 = Image.open("image.tiff")
    ok = (im1 == np.asarray(imp_pil2)).all()
    print(ok, im_pil.mode)
    
    im2 = sim.make_signal1(DEFAULT_SHAPE, amplitude1)
    im2 += c_noise + sim.make_noise(DEFAULT_SHAPE, noise)
    im2 = sim.add_vignetting(im2)
    im2 = np.clip(im2, 0, 0xffffff)
    im2 = im2.astype(np.int32)

    im = im2 - im1
    im -= np.min(im)

    buf = Felics.encode(im1, delta_min=c_delta_min)
    im3 = Felics.decode(buf)
    assert np.array_equal(im1, im3)
    print(c_delta_min, im1.size, len(buf), len(buf)/im1.size*8)

    buf = Felics.encode(im, delta_min=delta_min)
    im3 = Felics.decode(buf)
    assert np.array_equal(im, im3)
    print(delta_min, im.size, len(buf), len(buf)/im.size*8)

def run(args):
    # bench_bkg_level()   # No effect on compressed ratio
    # bench_amplitude()
    # bench_bits_per_pixel()
    # bench_context()
    # bench_other_format()
    # bench_context2()
    # simple_check()
    check_delta_compression()
