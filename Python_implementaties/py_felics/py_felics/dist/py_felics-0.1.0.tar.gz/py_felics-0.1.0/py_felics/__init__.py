import sys

import benchmark as benchmark
import cortex as cortex

__version__ = '0.1.0'


def run():
    args = sys.argv
    if args[1] == "benchmark":
        benchmark.run(args)
    elif args[1] == "cortex":
        cortex.run(args)
